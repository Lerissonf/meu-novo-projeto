event
=======

Esse diretório contém as apresentações e resumos publicados em eventos.
