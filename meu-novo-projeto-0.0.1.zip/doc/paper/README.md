paper
=======

Esse diretório contém o(s) manuscrito(s) do projeto.
