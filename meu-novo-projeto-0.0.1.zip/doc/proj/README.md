proj
=======

Esse diretório contém a descrição do projeto e outros documentos 
administrativos.
