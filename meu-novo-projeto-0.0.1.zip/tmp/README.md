tmp
======

Esse diretório contém arquivos temporários que podem ser deletados.
