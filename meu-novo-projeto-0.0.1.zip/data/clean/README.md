clean
=======

Esse diretório contém os dados do projeto preparados para análise.
