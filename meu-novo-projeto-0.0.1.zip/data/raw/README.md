raw
=======

Esse diretório contém os dados brutos do projeto, os quais não serão alterados.
