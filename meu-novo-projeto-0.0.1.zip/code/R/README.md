R
=======

Esse diretório contém código de programação na linguagem `R`.
