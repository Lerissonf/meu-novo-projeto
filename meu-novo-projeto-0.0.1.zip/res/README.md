res
=======

Esse diretório contém todos os resultados das análises.

