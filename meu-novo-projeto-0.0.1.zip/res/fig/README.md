fig
=======

Esse diretório contém os gráficos, geralmente usados como figuras do manuscrito.
