misc
=======

Esse diretório contém diagramas, imagens, e outros produtos diversos.
